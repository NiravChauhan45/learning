# Power-BI-7-Hours-Masterclass-Practice-Files-with-Project
Includes all the Practice Material and Project
