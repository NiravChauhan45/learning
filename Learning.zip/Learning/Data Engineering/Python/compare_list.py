"""
Compare Lists

a = [1, 2, 5, 6]
b = [1, 2, 7, 4]
"""


def comp(a, b):
    d = {}
    for i in a:
        d[i] = d.get(i, 0) + 1
    for i in d:
        d[i] = d.get(i, 0) + 1
    for i in d:
        if d[i] != 0:
            return False
    return True


if __name__ == '__main__':
    a = [1, 2, 5, 6]
    b = [1, 2, 7, 4]
    results = comp(a, b)
    print(results)

