
def even_odd():
    results = [i%2 for i in range(1,100+1)]

if __name__ == '__main__':
    results = even_odd()
    print(results)