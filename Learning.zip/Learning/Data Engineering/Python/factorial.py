# 1 * 2 * 3 * 4 * 5

def _factorial(num):
    if num == 0 or num == 1:
        return 1
    else:
        return num * _factorial(num - 1)


if __name__ == '__main__':
    num = int(input("Enter Number: "))
    print(f"The Factorial Is: {_factorial(num)}")
