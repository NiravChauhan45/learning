# # Todo: Divided by two or not
#
#
# divTwo = lambda x: "Even" if x % 2 == 0 else "Odd"
#
# print(divTwo(10))
#
# # Todo: List Comprehension
#
#
# lst = [45, 10, 12, 18, 3, 33]
#
# new_lst = [i if i % 2 == 0 else "No" for i in lst]
#
# print(new_lst)
#
#
# name = "Nirav Chauhan"
#
# print(name[:name.find(' ')])
#
# def numbers():
#     yield 1
#
#
# print(next(numbers()))  # 1 # 3
#
#
def sumx(n):
    if n > 10:  # base condition (stop)
        return
    print(n)
    sumx(n + 1)  # recursive call


sumx(1)
