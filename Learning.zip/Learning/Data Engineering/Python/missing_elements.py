'''
Question:
    You are given an array nums of length n containing integers from 1 to n. inclusive.
    There is exactly one integer that appears twise in nums, and one integers that is missing from nums.
    Return the pair [duplicate, missing].

Example:
    Input: [3, 1, 2, 5, 4]
    Output: [3, 4]
'''


def find_duplicate_missing(nums):
    duplicate = -1
    missing = -1

    # Find the duplicate number
    for num in nums:
        index = abs(num) - 1
        if nums[index] < 0:
            duplicate = abs(num)
        else:
            nums[index] *= -1

    # Find the missing number
    for i in range(len(nums)):
        if nums[i] > 0:
            missing = i + 1

    return [duplicate, missing]


if __name__ == '__main__':
    nums = [3, 1, 2, 5, 3]
    results = find_duplicate_missing(nums)
    print(results)
