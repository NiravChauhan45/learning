"""
Question: You must do this in-place without making a copy of the array

Example:
input: [0, 1, 0, 3, 12]
output: [1, 3, 12, 0, 0]

"""

lst = [0, 1, 0, 3, 12]


# Method - 1
def solve(lst):
    nlst = []
    n = 0
    for index, i in enumerate(lst):
        if i == 0:
            nlst.append(i)
        else:
            nlst[n], lst[index] = lst[index], nlst[n]
            nlst.append(0)
            n += 1
    return nlst


# Method - 2
def move_zeros_to_end(nums):
    non_zero_index = 0
    # Move all non-zero elements to the beginning
    for i in range(len(nums)):
        if nums[i] != 0:
            nums[non_zero_index] = nums[i]
            non_zero_index += 1

    # Fill the rest of the array with zeros
    for i in range(non_zero_index, len(nums)):
        nums[i] = 0
    return nums

rt = move_zeros_to_end(lst)
print(rt)