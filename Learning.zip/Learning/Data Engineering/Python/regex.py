import re

email = "nirav32@gmail.com"

pattern = r".*[a-zA-Z]\d{1,3}@gmail.com"

x = re.findall(pattern, email)

print(x)
