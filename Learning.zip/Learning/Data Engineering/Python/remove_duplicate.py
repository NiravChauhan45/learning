"""
Example:
    Input: nums = [0,0,1,1,1,1,2,3,3]
    Output: nums = [0,0,1,1,2,3,3]

Explanation:
    Your function should return k = 7, with the first seven elements of nums being 0,0,1,1,2,3 and 3 respectively.
    It does not matter what you leave beyond the returned k (hence they are underscores)

Constraints:
    --> 1 <= nums.length <= 3 * 104
    --> -104 <= nums[i] <= 104
    --> nums is sorted in non-decreasing order.
"""

from collections import Counter


def remove_duplicates(nums: list[int]) -> int:
    num_counter = Counter(nums)
    Threshold = 2
    Breaching_count = 0

    for count in num_counter.values():
        if count > Threshold:
            Breaching_count += count - Threshold
    return len(nums) - Breaching_count


if __name__ == '__main__':
    nums = [0, 0, 1, 1, 1, 1, 2, 3, 3]
    results = remove_duplicates(nums)
    print(results)
