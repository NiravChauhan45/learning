EXECUTE sp_helpindex `pdp_links_backup`;

SHOW INDEX FROM `pdp_links_backup`


SELECT DATEDIFF('2026-01-19','2025-01-19') AS date_diff