SELECT NOW() AS current_datetime;

SELECT CURDATE() AS current_date_;

SELECT CURRENT_TIME() AS current_time_;

SELECT SUBDATE('2026-02-12',15) AS sale_date_only


