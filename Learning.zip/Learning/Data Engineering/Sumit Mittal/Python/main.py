"""

Datastrcutures
===============

** Sequence
1) List [45,10,18]
2) Tuple(45,10,18)
3) range(0,9)
4) str "Nirav Chauhan"

** Sequence is not important
1) dictionary {"name":"nirav chauhan"}
2) set {"nirav","yash"}

** 4 Main data structures in python (collections types)

List = [45,10,18]
Tuple = (45,10,18)
Set = {"Nirav", "Hardik"}
Dictionary = {"Name":"Nirav Chauhan","Age":22}

* Sequence types - List, Tuple, String
Mutable vs Immutable

String - Immutable
List - Mutable
Tuple - Immutable
Set - Mutable
Dictionary - Mutable

"""