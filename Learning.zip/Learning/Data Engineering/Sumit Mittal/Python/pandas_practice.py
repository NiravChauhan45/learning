import pandas as pd

data = {
    "Name": ['Nirav', None, 'Hardik', 'Hito'],
    "Age": [22, 24, 23, 23],
    'City': ['Botad', 'Lakheni', 'Rajpara', 'Ahmedabad']
}

df = pd.DataFrame(data)
df.fillna('N/A', inplace=True)
print(df)
