import datetime

# pri = datetime.datetime.now()
# print(pri)

# Todo: List
orders = [1, "2026-02-04 11:13:34", 11599, "CLOSED"]
orders[3] = "Completed"

# SHow list of index
orders.index(11599)

# Add item
orders.append(100)

# Add item specific location
orders.insert(1, 100)
# print(orders)

# Todo: Tuple
orders_tuple = (1, '2026-02-04 11:13:34', 11599, 'CLOSED')

orders_amounts = [100, 200, None, "Invalid", 300, 400.5]
# sum = 0
# Todo: For Loop
# for i in orders_amounts:
#     if type(i) == int or type(i) == float:
#         sum = sum + i
#     else:
#         continue


# Todo: Using While Loop
# i = 0
# sum = 0
# while i < len(orders_amounts):
#     if type(orders_amounts[i]) == int or type(orders_amounts[i]) == float:
#         sum = sum + orders_amounts[i]
#     else:
#         i = i + 1
#         continue
#     i = i + 1
# print(sum)

customer_ids = [102, 105, 102, 103, 107, 109, 110, 109]
unique_customers = []
for i in customer_ids:
    if i in unique_customers:
        continue
    else:
        unique_customers.append(i)

print(unique_customers)