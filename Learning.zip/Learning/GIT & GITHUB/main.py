def _add(num1, num2):
    return num1 + num2


ppp = _add(45, 18)
print(ppp)
