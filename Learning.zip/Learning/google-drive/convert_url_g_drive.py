import os
from google.oauth2 import service_account
from googleapiclient.discovery import build

# Google Drive Setup
SERVICE_ACCOUNT_FILE = r'E:\Nirav\Learning\google-drive\vaibhav.json'
SCOPES = ['https://www.googleapis.com/auth/drive']

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES
)
service = build('drive', 'v3', credentials=creds)
# B0168I6AZ6_226021_11_07_2025.png
# Folder ID
folder_id = '1QSALKA5r72yQ2G_nHzji-oT09PXe9kin'

# Get Files from Folder
query = f"'{folder_id}' in parents and trashed = false"
results = service.files().list(q=query, pageSize=1000, fields="files(id, name, mimeType)").execute()
items = results.get('files', [])

if not items:
    print("No files found.")
else:
    for item in items:
        file_id = item['id']
        old_name = item['name']

        # ===== Rename =====
        new_name = f"NEW_{old_name}"
        service.files().update(fileId=file_id, body={'name': new_name}).execute()
        print(f"Renamed: {old_name} → {new_name}")

        # ===== Update metadata =====
        service.files().update(fileId=file_id, body={'description': 'Updated via script'}).execute()
        print(f"Metadata updated for: {new_name}")

