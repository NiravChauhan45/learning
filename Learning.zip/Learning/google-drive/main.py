from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle
import os

# If modifying scopes, delete token.pickle
SCOPES = ['https://www.googleapis.com/auth/drive']


def authenticate():
    creds = None
    if os.path.exists(r'/credentials.json'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('client_secret.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)
    return build('drive', 'v3', credentials=creds)


service = authenticate()

folder_id = '1AbCdEfGhIjKlMnOpQr'  # your folder ID
file_name_to_change = 'old_name.txt'

results = service.files().list(
    q=f"name='{file_name_to_change}' and '{folder_id}' in parents",
    fields="files(id, name)"
).execute()

files = results.get('files', [])
if not files:
    print("File not found in this folder.")
else:
    file_id = files[0]['id']
    print(f"Found file: {files[0]['name']} (ID: {file_id})")

new_name = 'new_name.txt'
updated_file = service.files().update(
    fileId=file_id,
    body={'name': new_name}
).execute()

print(f"Renamed to: {updated_file['name']}")
