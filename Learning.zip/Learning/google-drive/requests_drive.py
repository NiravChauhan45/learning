import requests

url = "https://drive.google.com/drive/folders/1-kg6RsumcKqnAgxTjRd0nyUK7fWENn8z"

# You need to specify a method (e.g., "GET")
pp = requests.request("GET", url)
print(pp.status_code)   # Prints the HTTP status code
print(pp.text)    # Prints first 500 characters of the response body
