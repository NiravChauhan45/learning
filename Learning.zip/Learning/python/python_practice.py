lst = [1,2,4,5]
lst.reverse()
print(lst[::-1])

# lst.insert(1,45)
#
# print(lst)
# lst.remove(2)
# # print(lst.remove(2))
# lst.pop()
# print(lst)